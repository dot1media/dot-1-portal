# Branding Guide

Make the app yours. One file holds your brand, and one command applies it.

## The one file

`brand.config.json` is the single source of truth for your look:

- **org**: your name, legal name, tagline, domain, and contact email
- **colors**: primary, secondary, ink (text), paper (surfaces), bone (warm background)
- **fonts**: display, body, and label typefaces
- **logo**: the paths to your light and dark logo files

## Apply it

```
npm run brand
```

This detects whether you are running the Studio or the Newsroom and does the right thing for each:

- Puts your **primary color** everywhere the app uses its accent, buttons, links, highlights, and the like
- Sets **ink, paper, and warm background** to your palette
- Installs your **logo** into the app
- Writes your **name and tagline** into the app's identity

Run it again any time you change the config. It is safe to repeat.

## What changes, and what to check

After applying, run the app and look at the header, the buttons, and any accent color. They should be yours. If something still shows the old color, it usually means that value in `brand.config.json` was left blank.

## Fonts

The color and logo changes are automatic. Changing typefaces is a guided manual step, because a new font also has to be loaded. Set your font names in `brand.config.json`, then follow the font-loading note in the app's own README. If you would like the standard three (an elegant serif, a clean sans, and a mono for labels), they are already set.

## Going deeper

This kit brands the visible surface: color, logo, and identity. If you want a deeper custom look, every screen is standard, readable code, and we are glad to help tailor it. Reach us at contact@dot1.media.
