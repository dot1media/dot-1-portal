# Dot One Studio and Newsroom

Your own client studio and newsroom, self-hosted and fully branded. This kit installs the software, applies your branding, verifies the setup, and gets you running.

## What is included

- A guided, verified installer that checks each step
- A branding import that puts your logo, colors, and identity into the app
- Health checks so you know the install is sound before you go live
- These guides

## Quick start

1. Put your logo files in the `brand/` folder.
2. Copy `brand.config.example.json` to `brand.config.json` and fill in your details.
3. Copy `.env.example` to `.env` and fill in your database and Square keys.
4. Run the installer:

```
npm run setup
npm run setup:finish
```

The installer applies your brand, prepares the database, and verifies everything. When it finishes clean, you are ready to run locally with `npm run dev` or deploy to your host.

Add these lines to your `package.json` scripts if they are not already there:

```
"setup": "node scripts/setup.mjs",
"setup:finish": "node scripts/setup.mjs --finish",
"brand": "node scripts/apply-brand.mjs",
"verify": "node scripts/verify-install.mjs"
```

Full steps are in INSTALL.md. Branding is in BRANDING.md.

Questions or a hand with setup: contact@dot1.media
