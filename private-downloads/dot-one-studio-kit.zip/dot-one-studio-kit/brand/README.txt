Put your logo files here (logo.png, logo-white.png).
