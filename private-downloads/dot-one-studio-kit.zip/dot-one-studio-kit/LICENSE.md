# License Guide

Your copy is licensed to you. The app checks for a valid license and will not run until one is in place. This is quick and one time.

## Install the license gate

From the app folder:

```
node scripts/install-license.mjs
```

This adds the activation screen and the license check. If the app already has its own middleware file, the installer will tell you to merge instead of overwriting, so nothing of yours is lost.

## Enter your license

1. Open your `.env` file.
2. Set `LICENSE_KEY` to the key from your purchase (it was shown on your thank-you page and is in your receipt).
3. Start or restart the app.

That is all. Until a valid key is set, every page shows the activation screen, so there is no way to use the app by accident before it is licensed.

## The activation screen

If you are not sure your key is right, open the app before setting the key. It shows an activation screen where you can paste the key and check it. When it says the key is valid, set it as `LICENSE_KEY` and restart.

## How it works, briefly

Your license is signed and is verified inside the app using a public key. It does not phone home, so it works offline and keeps working even if our servers are down. Keep your key private, it is tied to your purchase.

Lost your key or need another install: contact@dot1.media
