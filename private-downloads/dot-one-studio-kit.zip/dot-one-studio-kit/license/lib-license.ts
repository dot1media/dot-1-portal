import crypto from "crypto";
// Verifies a license offline with the embedded public key.
const PUB = "MCowBQYDK2VwAyEA0nT2V93qrEaNy6/mGDob+fXZSyjGCj4aUXaXCLH/wkA=";
const fromB64url = (s: string) => Buffer.from(s.replace(/-/g,"+").replace(/_/g,"/"), "base64");
export function verifyLicense(key: string): { valid: boolean; payload?: any } {
  try {
    const [p, s] = String(key||"").split(".");
    if (!p || !s) return { valid: false };
    const data = fromB64url(p), sig = fromB64url(s);
    const pub = crypto.createPublicKey({ key: Buffer.from(PUB, "base64"), format: "der", type: "spki" });
    if (!crypto.verify(null, data, pub, sig)) return { valid: false };
    const payload = JSON.parse(data.toString());
    if (payload.exp && Date.now() > payload.exp) return { valid: false };
    return { valid: true, payload };
  } catch { return { valid: false }; }
}
