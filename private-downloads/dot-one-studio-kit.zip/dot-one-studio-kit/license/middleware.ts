import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";

// License gate. Until a valid LICENSE_KEY is set, every page is sent to /activate.
// The key is verified offline with the embedded public key, so no server is needed.
const PUB = "MCowBQYDK2VwAyEA0nT2V93qrEaNy6/mGDob+fXZSyjGCj4aUXaXCLH/wkA=";
function b64ToBytes(s: string){ const bin = atob(s); const b = new Uint8Array(bin.length); for (let i=0;i<bin.length;i++) b[i]=bin.charCodeAt(i); return b; }
function b64urlToBytes(s: string){ s = s.replace(/-/g,"+").replace(/_/g,"/"); while (s.length % 4) s += "="; return b64ToBytes(s); }
async function licenseValid(key: string){
  try {
    const [p, sig] = (key||"").split(".");
    if (!p || !sig) return false;
    const data = b64urlToBytes(p), signature = b64urlToBytes(sig);
    const pub = await crypto.subtle.importKey("spki", b64ToBytes(PUB), { name: "Ed25519" }, false, ["verify"]);
    if (!(await crypto.subtle.verify({ name: "Ed25519" }, pub, signature, data))) return false;
    const payload = JSON.parse(new TextDecoder().decode(data));
    return !(payload.exp && Date.now() > payload.exp);
  } catch { return false; }
}
export async function middleware(req: NextRequest){
  if (await licenseValid((process.env.LICENSE_KEY || "").trim())) return NextResponse.next();
  const url = req.nextUrl.clone(); url.pathname = "/activate";
  return NextResponse.rewrite(url);
}
export const config = { matcher: ["/((?!activate|api/activate|_next/static|_next/image|favicon.ico|.*\\..*).*)"] };
