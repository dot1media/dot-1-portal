import { NextResponse } from "next/server";
import { verifyLicense } from "@/lib/license";
export const runtime = "nodejs";
export async function POST(req: Request) {
  const body: any = await req.json().catch(() => ({}));
  const r = verifyLicense(String(body.key || "").trim());
  if (!r.valid) return NextResponse.json({ ok: false, error: "That license key is not valid." }, { status: 400 });
  return NextResponse.json({ ok: true, plan: (r.payload && r.payload.plan) || "license" });
}
