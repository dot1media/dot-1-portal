#!/usr/bin/env node
// Installs the license gate into this app. Safe: it will not overwrite an
// existing middleware.ts, it tells you to merge instead.
import fs from "node:fs";
import path from "node:path";
const root = process.cwd();
const ok = (m) => console.log("  \x1b[32m\u2713\x1b[0m " + m);
const warn = (m) => console.log("  \x1b[33m!\x1b[0m " + m);
const put = (from, to, mkdirs) => {
  const dest = path.join(root, to);
  if (mkdirs) fs.mkdirSync(path.dirname(dest), { recursive: true });
  fs.copyFileSync(path.join(root, from), dest); ok(`Installed ${to}`);
};
console.log("\nInstalling the license gate...\n");
if (fs.existsSync(path.join(root, "middleware.ts")) || fs.existsSync(path.join(root, "middleware.js"))) {
  warn("You already have a middleware file. Open license/middleware.ts and merge its logic in by hand, then continue.");
} else put("license/middleware.ts", "middleware.ts");
put("license/lib-license.ts", "lib/license.ts", true);
put("license/activate-page.tsx", "app/activate/page.tsx", true);
put("license/activate-route.ts", "app/api/activate/route.ts", true);
// ensure LICENSE_KEY is in the env example
const envx = path.join(root, ".env.example");
if (fs.existsSync(envx)) { let t = fs.readFileSync(envx, "utf8"); if (!/LICENSE_KEY/.test(t)) { fs.writeFileSync(envx, t.trimEnd() + "\n\n# Your license key, from your purchase. Required before first use.\nLICENSE_KEY=\n"); ok("Added LICENSE_KEY to .env.example"); } }
console.log("\n\x1b[32mLicense gate installed.\x1b[0m Set LICENSE_KEY in your .env, then start the app. Until then, every page shows the activation screen.\n");
