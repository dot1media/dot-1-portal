#!/usr/bin/env node
// Applies brand.config.json to the app: color palette, logo, and identity.
// Safe and idempotent. Only changes keys it finds, and reports each one.
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const ok = (m) => console.log("  \x1b[32m\u2713\x1b[0m " + m);
const info = (m) => console.log("  \x1b[36m\u2192\x1b[0m " + m);
const warn = (m) => console.log("  \x1b[33m!\x1b[0m " + m);

function loadConfig() {
  const p = path.join(root, "brand.config.json");
  if (!fs.existsSync(p)) {
    console.error("\x1b[31mNo brand.config.json found.\x1b[0m Copy brand.config.example.json to brand.config.json and edit it first.");
    process.exit(1);
  }
  try { return JSON.parse(fs.readFileSync(p, "utf8")); }
  catch (e) { console.error("brand.config.json is not valid JSON: " + e.message); process.exit(1); }
}

function detectApp() {
  if (fs.existsSync(path.join(root, "lib", "brand.js"))) return "studio";
  const css = path.join(root, "app", "globals.css");
  if (fs.existsSync(css) && fs.readFileSync(css, "utf8").includes("--crimson")) return "newsroom";
  return null;
}

function replaceAllHex(text, key, hex, style) {
  // Global: every occurrence. style 'js': key: "#xxx" | style 'css': --key:#xxx
  const re = style === "js"
    ? new RegExp("(\\b" + key + "\\s*:\\s*\")#[0-9a-fA-F]{3,8}(\")", "g")
    : new RegExp("(--" + key + "\\s*:\\s*)#[0-9a-fA-F]{3,8}", "g");
  const before = text;
  const after = text.replace(re, style === "js" ? `$1${hex}$2` : `$1${hex}`);
  return { text: after, changed: after !== before };
}

function applyColors(cfg, app) {
  const c = cfg.colors || {};
  const org = cfg.org || {};
  if (app === "studio") {
    const f = path.join(root, "lib", "brand.js");
    let t = fs.readFileSync(f, "utf8");
    // In the Studio, the primary maps to every 'red' token (including news.red).
    const map = { red: c.primary, ink: c.ink, paper: c.paper, cream: c.bone };
    let n = 0;
    for (const [k, v] of Object.entries(map)) { if (!v) continue; const r = replaceAllHex(t, k, v, "js"); if (r.changed) { t = r.text; n++; } }
    if (org.tagline) { const rt = t.replace(/(tagline\s*:\s*")[^"]*(")/, `$1${org.tagline}$2`); if (rt !== t) { t = rt; } }
    fs.writeFileSync(f, t);
    ok(`Studio palette applied to lib/brand.js (${n} color group(s))`);
  } else {
    const f = path.join(root, "app", "globals.css");
    let t = fs.readFileSync(f, "utf8");
    const map = { crimson: c.primary, gold: c.secondary, ink: c.ink, paper: c.paper, bone: c.bone, cream: c.bone };
    let n = 0;
    for (const [k, v] of Object.entries(map)) { if (!v) continue; const r = replaceAllHex(t, k, v, "css"); if (r.changed) { t = r.text; n++; } }
    fs.writeFileSync(f, t);
    ok(`Newsroom palette applied to app/globals.css (${n} variable(s))`);
  }
}

function applyLogo(cfg, app) {
  const logo = cfg.logo || {};
  const pub = path.join(root, "public");
  if (!fs.existsSync(pub)) { warn("No public/ folder found, skipping logo copy."); return; }
  const targets = app === "studio"
    ? { light: ["dot1-logo.png", "dot1-logo-print.png"], dark: ["dot1-logo-white.png"] }
    : { light: ["logo.png"], dark: ["logo-white.png"] };
  for (const [variant, files] of Object.entries(targets)) {
    const src = logo[variant] && path.join(root, logo[variant]);
    if (!src || !fs.existsSync(src)) { warn(`No ${variant} logo at ${logo[variant] || "(unset)"}, skipping.`); continue; }
    for (const name of files) fs.copyFileSync(src, path.join(pub, name));
    ok(`${variant} logo installed (${files.join(", ")})`);
  }
}

function stampIdentity(cfg) {
  // Keep the resolved identity beside the app so future surfaces can read it.
  fs.writeFileSync(path.join(root, "brand.config.json"), JSON.stringify(cfg, null, 2));
  const org = cfg.org || {};
  if (org.name) ok(`Identity set: ${org.name}${org.tagline ? " (" + org.tagline + ")" : ""}`);
}

console.log("\nApplying your brand...\n");
const cfg = loadConfig();
const app = detectApp();
if (!app) { console.error("\x1b[31mCould not tell which app this is.\x1b[0m Run this from the Studio or Newsroom app folder."); process.exit(1); }
info(`Detected: ${app === "studio" ? "Studio (client portal)" : "Newsroom (editorial + news)"}`);
applyColors(cfg, app);
applyLogo(cfg, app);
stampIdentity(cfg);
console.log("\n\x1b[32mBrand applied.\x1b[0m Run 'npm run build' to see it, or continue the installer.\n");
