#!/usr/bin/env node
// One guided, verified install. Runs each step, checks it, and stops with a
// clear message if something is wrong. Safe to run more than once.
import { execSync } from "node:child_process";
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
const run = (cmd) => execSync(cmd, { stdio: "inherit" });
const step = (n, m) => console.log(`\n\x1b[1m\x1b[36mStep ${n}: ${m}\x1b[0m`);
const ok = (m) => console.log("  \x1b[32m\u2713\x1b[0m " + m);

console.log("\n\x1b[1mDot One Studio and Newsroom, guided install\x1b[0m");
console.log("This walks you through setup and verifies each step.\n");

// 1. Prerequisites
step(1, "Checking prerequisites");
const major = Number(process.versions.node.split(".")[0]);
if (major < 18) { console.error("  Node 18 or newer is required. Yours is " + process.versions.node); process.exit(1); }
ok(`Node ${process.versions.node}`);

// 2. Config files
step(2, "Preparing your config files");
const ensure = (example, real, label) => {
  if (!fs.existsSync(path.join(root, real))) {
    if (fs.existsSync(path.join(root, example))) { fs.copyFileSync(path.join(root, example), path.join(root, real)); console.log(`  Created ${real} from the example. \x1b[33mEdit it before continuing.\x1b[0m`); }
    else console.log(`  \x1b[33m${real} is missing and no example was found.\x1b[0m`);
  } else ok(`${label} present`);
};
ensure("brand.config.example.json", "brand.config.json", "Brand config");
ensure(".env.example", ".env", "Environment file");

console.log("\n  Before the next steps, make sure brand.config.json and .env are filled in.");
console.log("  When ready, run: \x1b[1mnpm run setup:finish\x1b[0m\n");

if (process.argv.includes("--finish")) {
  // 3. Install
  step(3, "Installing dependencies");
  run("npm install");
  ok("Dependencies installed");

  // 4. Branding
  step(4, "Applying your brand");
  run("node scripts/apply-brand.mjs");

  // 5. Database
  step(5, "Preparing the database");
  const pkg = JSON.parse(fs.readFileSync(path.join(root, "package.json"), "utf8"));
  if (pkg.scripts && pkg.scripts["db:init"]) { run("npm run db:init"); ok("Database initialized"); }
  else console.log("  No db:init script found. The app initializes its schema on first run, so this is fine.");

  // 6. Verify
  step(6, "Verifying the install");
  run("node scripts/verify-install.mjs");

  console.log("\n\x1b[32m\x1b[1mInstall complete.\x1b[0m Start it with 'npm run dev' locally, or deploy to your host.\n");
}
