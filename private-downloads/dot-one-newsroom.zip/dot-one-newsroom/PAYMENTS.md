# Payments Guide

You take payments through your own account, so the money is yours from the first sale. Nothing routes through us.

## Connecting your processor

The app uses Square as its built-in processor. You connect your own Square account:

1. Sign in to your Square dashboard and open the developer or API section.
2. Create an access token for your account, and note your location ID.
3. Put both into your `.env`:

```
SQUARE_ACCESS_TOKEN=your token
SQUARE_LOCATION_ID=your location id
SQUARE_ENV=production
```

Use `sandbox` for `SQUARE_ENV` while you are testing, then switch to `production` when you are ready to take real payments. For refunds and receipts to work smoothly, also set `SQUARE_WEBHOOK_SIGNATURE_KEY` from your Square webhook settings.

## Where the money goes

Every payment settles into the Square account whose keys you entered. Your customers check out, and you are paid directly. We never touch it.

## Using a different processor

Square is built in and is the fastest path to taking payments. If you need a different processor, such as Stripe or PayPal, the payment step is written in one place so it can be adapted. That is custom work rather than a setting, and we are happy to help. Reach us at support@dot1.media.
