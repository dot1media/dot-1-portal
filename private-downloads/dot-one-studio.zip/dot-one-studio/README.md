# Dot One Studio

Your own client portal: booking, a service menu, payments, and project tracking. Self-hosted, fully branded, and yours to run.

## What is included

- The full application source
- A guided, verified installer that checks each step
- A branding import that applies your logo, colors, and identity
- A license gate you activate before first use
- Payments through your own Square account
- Guides for install, branding, payments, your license, and connecting a web address

## Quick start

1. Put your logo files in `brand/`.
2. Copy `brand.config.example.json` to `brand.config.json` and fill it in.
3. Copy `.env.example` to `.env` and add your database, Square, and license values.
4. Run the installer:

```
npm run setup
npm run setup:finish
```

Add these to your `package.json` scripts if they are not present:

```
"setup": "node scripts/setup.mjs",
"setup:finish": "node scripts/setup.mjs --finish",
"brand": "node scripts/apply-brand.mjs",
"verify": "node scripts/verify-install.mjs"
```

Install steps are in INSTALL.md. Branding is in BRANDING.md, payments in PAYMENTS.md, your license in LICENSE.md, and connecting a web address in DOMAINS.md.

Any issue at all, we are here: support@dot1.media
