# Dot One Studio

Your own client portal: booking, a service menu, payments, and project tracking. Self-hosted, fully branded, and yours to run.

## What is included

- The full application source
- A guided, verified installer that checks each step
- A built-in setup screen: enter your name, tagline, logo, and colors, and the app takes on your brand instantly, no code
- Payments through your own processor: Square, Stripe, or PayPal
- A license gate you activate before first use
- Guides for install, branding, payments, your license, and connecting a web address

## Quick start

1. Copy `.env.example` to `.env`, choose your payment processor, and add your database and license values.
2. Run the installer:

```
npm run setup
npm run setup:finish
```

3. Open the app, create your admin account. Because this is a self-install copy, it sends you straight to the setup screen the first time. Add your logo, colors, and name, and save.

Install steps are in INSTALL.md. Payments in PAYMENTS.md, your license in LICENSE.md, and connecting a web address in DOMAINS.md.

## Before you go live, make it yours

The setup screen handles your name, tagline, logo, and colors. A few text items still ship with placeholders that you should replace with your own:

- The Terms of Service and Privacy Policy pages. Put your own in. Email support@dot1.media if you would like a plain template to start from.
- The footer social links and any contact details.

Any issue at all, we are here: support@dot1.media
