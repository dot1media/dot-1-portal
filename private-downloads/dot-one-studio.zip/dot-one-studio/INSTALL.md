# Install Guide

A calm, step-by-step setup. Each step is checked, so you always know where you stand.

## Before you start

You need three things:

1. **Node 18 or newer.** Check with `node --version`.
2. **A Postgres database.** A free Neon or Supabase project works well. Copy its connection string.
3. **Square keys** for payments: your access token and location ID from the Square dashboard. These are optional if you are only trying the app out.

## Step by step

**1. Add your logo.** Drop your logo image into the `brand/` folder. A transparent PNG works best. A light-background version and a dark-background version are ideal, but one is fine to start.

**2. Set your identity.** Copy `brand.config.example.json` to `brand.config.json` and fill in your organization name, tagline, colors, and the paths to your logo files.

**3. Set your environment.** Copy `.env.example` to `.env` and paste in your `DATABASE_URL`, your Square keys, and the `ADMIN_EMAIL` that should receive admin access on first run.

**4. Run the installer.**

```
npm run setup
```

This creates any missing config files and reminds you to fill them in. Once your `brand.config.json` and `.env` are ready:

```
npm run setup:finish
```

This installs dependencies, applies your brand, prepares the database, and verifies the whole install with a checklist.

**5. Confirm.** You should see every check pass. If any check fails, the message tells you exactly what to fix. Run `npm run verify` any time to re-check.

## Running it

- **Locally:** `npm run dev`, then open the address it prints. Good for trying it out and for a single-computer setup.
- **On the web:** deploy the folder to your own host. Any host that runs Next.js works. Set the same environment variables there that you set in `.env`.

## Troubleshooting

- **A check failed for a missing environment variable.** Open `.env` and make sure that value is filled in, then run `npm run verify`.
- **The database step reported nothing to do.** That is normal. The app builds its own tables on first run.
- **Your brand did not change.** Make sure `brand.config.json` has real values, then run `npm run brand` and rebuild.

You do not have to do this alone. Reach us at support@dot1.media.
