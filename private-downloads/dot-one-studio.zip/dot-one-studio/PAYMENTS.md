# Payments Guide

You take payments through your own account, with whichever processor you prefer. Pick one, paste its keys, and you are done. The money is yours from the first sale, and nothing routes through us.

## Choose your processor

In your `.env`, set `PAYMENT_PROVIDER` to one of `square`, `stripe`, or `paypal`. Then fill in only that section. You do not need keys for the others.

```
PAYMENT_PROVIDER=square
```

## Square

1. Sign in to your Square dashboard and open the developer section.
2. Create an access token, and note your location id.
3. In `.env`:

```
SQUARE_ACCESS_TOKEN=your token
SQUARE_LOCATION_ID=your location id
SQUARE_ENV=production
```

Use `sandbox` for `SQUARE_ENV` while testing.

## Stripe

1. Sign in to your Stripe dashboard, open Developers, then API keys.
2. Copy your secret key.
3. In `.env`:

```
STRIPE_SECRET_KEY=your secret key
```

Use a test secret key while testing, then swap in the live one.

## PayPal

1. Open the PayPal developer dashboard and create an app.
2. Copy the client id and the secret.
3. In `.env`:

```
PAYPAL_CLIENT_ID=your client id
PAYPAL_SECRET=your secret
PAYPAL_ENV=live
```

Use `sandbox` for `PAYPAL_ENV` while testing.

## Where the money goes

Every payment settles into the account whose keys you entered. Your customers check out on a secure page hosted by your processor, and you are paid directly.

## Testing before you go live

Put your processor in its test mode, run one payment end to end, and confirm it lands. Then switch to live keys. If anything looks off, we are glad to help: support@dot1.media
