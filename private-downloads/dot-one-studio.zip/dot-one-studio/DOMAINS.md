# Domains Guide

Put the app on the internet under your own name, alongside your existing website. Two steps: put the app on a host, then point a web address at it.

## Step 1: Put the app on a host

This app runs on any host that supports Next.js. The simplest is Vercel:

1. Create a free account and a new project, and upload this folder (or connect it from a Git repository).
2. Add your environment values from `.env` in the project settings.
3. Deploy. You will get a temporary address like your-app.vercel.app to confirm it works.

If you prefer your own server, any Node host works. Set the same environment values, run the build, and start it.

## Step 2: Point a web address at it

Most people put this on a subdomain of their existing site, so their main website stays exactly as it is and the app lives beside it. For a studio, something like studio.yourdomain.com. For a newsroom, news.yourdomain.com.

You add one DNS record at whoever manages your domain. Your host tells you the exact target; on Vercel you add the subdomain in the project's Domains screen and it shows you what to enter. It is almost always a CNAME record. Here is where to add it with the common providers.

**GoDaddy**: Sign in, open My Products, next to your domain choose DNS. Under Records, Add, type CNAME, Name is your subdomain (studio), Value is the target your host gave you, Save.

**Namecheap**: Sign in, Domain List, Manage next to your domain, Advanced DNS. Add New Record, CNAME Record, Host is your subdomain, Target is the host's target, save the green check.

**Cloudflare**: Sign in, pick your domain, DNS, Records, Add record, CNAME, Name is your subdomain, Target is the host's target. Set proxy status to DNS only unless your host says otherwise, Save.

**Squarespace (formerly Google Domains)**: Sign in, Domains, your domain, DNS Settings, add a Custom Record, CNAME, Host is your subdomain, Data is the host's target, Save.

**Wix**: Sign in, Domains, the three dots by your domain, Manage DNS Records, add a CNAME under CNAME (Aliases), Host Name is your subdomain, Value is the host's target, Save.

**Bluehost**: Sign in, Domains, DNS, find the Zone Editor, add a CNAME, Host Record is your subdomain, Points To is the host's target, Save.

DNS can take a few minutes to a few hours to take effect. When it does, your app answers at your subdomain, and you can link to it from your existing site's menu.

## Adding it to your existing website

The clean way is the subdomain above, linked from your main menu, so both sites stay independent and simple. If instead you want the app to appear under a path on your main domain, such as yourdomain.com/studio, that needs a reverse proxy on your main site, which is more involved. We are glad to help you set that up.

Stuck on any of this: support@dot1.media
