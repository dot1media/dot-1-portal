#!/usr/bin/env node
// Verifies the install is sound. Exits non-zero if anything required is missing,
// so setup can trust it. Prints a clear checklist.
import fs from "node:fs";
import path from "node:path";

const root = process.cwd();
let fail = 0;
const pass = (m) => console.log("  \x1b[32m\u2713\x1b[0m " + m);
const bad  = (m) => { console.log("  \x1b[31m\u2717\x1b[0m " + m); fail++; };

function readEnv() {
  const p = path.join(root, ".env");
  if (!fs.existsSync(p)) return {};
  const out = {};
  for (const line of fs.readFileSync(p, "utf8").split("\n")) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m) out[m[1]] = m[2];
  }
  return out;
}

console.log("\nVerifying install...\n");

// 1. Node version
const major = Number(process.versions.node.split(".")[0]);
major >= 18 ? pass(`Node ${process.versions.node}`) : bad(`Node ${process.versions.node} is too old, need 18 or newer`);

// 2. Dependencies installed
fs.existsSync(path.join(root, "node_modules")) ? pass("Dependencies installed") : bad("Dependencies not installed, run: npm install");

// 3. Brand config
const bc = path.join(root, "brand.config.json");
if (fs.existsSync(bc)) {
  try { const c = JSON.parse(fs.readFileSync(bc, "utf8")); (c.org && c.org.name && c.org.name !== "Your Organization") ? pass(`Brand configured for ${c.org.name}`) : bad("brand.config.json still has placeholder values, edit it"); }
  catch { bad("brand.config.json is not valid JSON"); }
} else bad("No brand.config.json, copy the example and edit it");

// 4. Required env vars
const env = readEnv();
for (const key of ["DATABASE_URL", "ADMIN_EMAIL"]) {
  env[key] && env[key].trim() ? pass(`${key} set`) : bad(`${key} missing in .env`);
}

// 4b. Payment processor keys, for whichever one is chosen
const provider = (env.PAYMENT_PROVIDER || "square").toLowerCase();
const need = { square: ["SQUARE_ACCESS_TOKEN", "SQUARE_LOCATION_ID"], stripe: ["STRIPE_SECRET_KEY"], paypal: ["PAYPAL_CLIENT_ID", "PAYPAL_SECRET"] }[provider];
if (!need) bad(`PAYMENT_PROVIDER is "${provider}", which is not one of square, stripe, paypal`);
else { pass(`Payment processor: ${provider}`); for (const k of need) env[k] && env[k].trim() ? pass(`${k} set`) : bad(`${k} missing in .env (needed for ${provider})`); }

// 5. Logo present in public
const pub = path.join(root, "public");
const anyLogo = fs.existsSync(pub) && fs.readdirSync(pub).some((f) => /logo.*\.(png|svg|webp)$/i.test(f));
anyLogo ? pass("Logo installed in public/") : bad("No logo found in public/, run: npm run brand");

console.log("");
if (fail) { console.log(`\x1b[31m${fail} check(s) need attention before you go live.\x1b[0m\n`); process.exit(1); }
console.log("\x1b[32mAll checks passed. You are ready to build and deploy.\x1b[0m\n");
