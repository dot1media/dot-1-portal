"use client";
import { useState } from "react";
export default function Activate() {
  const [key, setKey] = useState(""); const [msg, setMsg] = useState(""); const [ok, setOk] = useState(false); const [busy, setBusy] = useState(false);
  async function check() {
    setBusy(true); setMsg("");
    try {
      const r = await fetch("/api/activate", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ key: key.trim() }) });
      const d = await r.json();
      if (d.ok) { setOk(true); setMsg("This license is valid. Set it as LICENSE_KEY in your environment, then restart the app to unlock it."); }
      else { setOk(false); setMsg(d.error || "That key is not valid."); }
    } catch { setMsg("Could not check the key. Please try again."); }
    setBusy(false);
  }
  return (
    <div style={{ maxWidth: 560, margin: "12vh auto", padding: "0 24px", fontFamily: "system-ui, sans-serif", color: "#141210" }}>
      <h1 style={{ fontSize: 28, marginBottom: 8 }}>Activate your license</h1>
      <p style={{ color: "#6f6d65", marginBottom: 18, lineHeight: 1.6 }}>Enter the license key from your purchase to unlock the app. You will set it as an environment variable named <b>LICENSE_KEY</b>, then restart.</p>
      <textarea value={key} onChange={(e) => setKey(e.target.value)} placeholder="Paste your license key" style={{ width: "100%", minHeight: 90, padding: 12, borderRadius: 8, border: "1px solid #e2ded4", fontFamily: "monospace", fontSize: 13, boxSizing: "border-box" }} />
      <button onClick={check} disabled={busy} style={{ marginTop: 12, padding: "11px 20px", borderRadius: 999, border: 0, background: "#b81616", color: "#fff", fontWeight: 600, cursor: "pointer" }}>{busy ? "Checking..." : "Check license"}</button>
      {msg && <p style={{ marginTop: 14, color: ok ? "#2f8f6b" : "#b3261e", lineHeight: 1.6 }}>{msg}</p>}
      <p style={{ marginTop: 22, fontSize: 13, color: "#9a988f" }}>Trouble activating? Email <a href="mailto:support@dot1.media" style={{ color: "#b81616" }}>support@dot1.media</a>.</p>
    </div>
  );
}
